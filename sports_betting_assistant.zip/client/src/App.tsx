import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Events from "./pages/Events";
import ParlayBuilder from "./pages/ParlayBuilder";
import BettingHistory from "./pages/BettingHistory";
import Advisor from "./pages/Advisor";
import Settings from "./pages/Settings";
import ResponsibleGambling from "./pages/ResponsibleGambling";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/events" component={Events} />
      <Route path="/events/:sportKey" component={Events} />
      <Route path="/parlay" component={ParlayBuilder} />
      <Route path="/history" component={BettingHistory} />
      <Route path="/advisor" component={Advisor} />
      <Route path="/settings" component={Settings} />
      <Route path="/responsible-gambling" component={ResponsibleGambling} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
